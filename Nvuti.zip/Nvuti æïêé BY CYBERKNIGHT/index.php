<?php
  require("inc/site_config.php"); 
require("inc/main.php"); 


?>