<script>
 setTimeout(function() {
   location.href = '/';
 }, 1000);
</script>